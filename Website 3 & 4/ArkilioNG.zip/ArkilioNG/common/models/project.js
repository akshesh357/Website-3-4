'use strict';

module.exports = function(Project) {

};

'use strict';

module.exports = function(Milestone) {

};

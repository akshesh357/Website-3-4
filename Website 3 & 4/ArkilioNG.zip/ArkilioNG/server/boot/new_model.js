'use strict';

var async = require('async');
module.exports = function(app) {
  //data sources

  var xamppDs = app.dataSources.xamppDs;
  createClients (function(err, clients){
    console.log('clients is created'+clients);

    createProjects( clients, function(err, projects){

      console.log('projects is created'+projects);

      createMilestones( projects, function(err, milestones){
        console.log('milestones is created'+milestones);

      });
    });
  });



  //create all models
  // async.parallel({
  //   clients: async.apply(createClients),
  // }, function(err, results) {
  //   if (err) throw err;
  //   console.log(results);
  //   async.parallel({
  //     projects:async.apply(createProjects( results.clients, function(err) {console.log('> models created sucessfully');})),
  //   },function(err,results){
  //     if (err) throw err;
  //     createMilestones( results.projects, function(err) {
  //       console.log('> milestone created sucessfully');
  //     });
  //   });
  // });
  function createClients(cb) {
    xamppDs.automigrate('Client', function(err) {
      if (err) return cb(err);
      var Client = app.models.Client;
      Client.create([{
        client_name: 'ekta',
        company_name:'lambton',
        address:'45,hdjbcxzjdk',
        city:'toronto',
        province:'ON',
        postal_code:'M1P3D4',
        email:'abc@gmail.com',
        contact:'9547862130',
        username:'abc@gmail.com',
        password:'abcd123'
      }, {
        client_name: 'ekta1',
        company_name:'lambton1',
        address:'45,hdjbcxzjdk',
        city:'toronto1',
        province:'ON1',
        postal_code:'M1P3D4',
        email:'abc1@gmail.com',
        contact:'9547862',
        username:'abc1@gmail.com',
        password:'abcd123'
      }, ], cb);
    });
  }
  //create reviews
  function createProjects(clients, cb) {
    xamppDs.automigrate('Project', function(err) {
      if (err) return cb(err);
      var Project = app.models.Project;

      Project.create([{
        project_name: 'java',
        project_description:'lambtonsdczx',
        project_cost:'$45',
        project_deadline:'nov-12-2017',
        invoice_frequency:'rwdsvfds',
        client_id:clients[1].id
      }, {
        project_name: 'java2',
        project_description:'ladsfxczdaxz',
        project_cost:'$65',
        project_deadline:'nov-28-2017',
        invoice_frequency:'gtefdscxz',
        client_id:clients[0].id
      }], cb);
    });
  }

  function createMilestones(projects, cb) {
    xamppDs.automigrate('Milestone', function(err) {
      if (err) return cb(err);
      var Milestone = app.models.Milestone;

      Milestone.create([{
        typeof_milestone: 'Design',
        percentage:'10%',
        priceof_milestone:'18',
        reminder:'2017-11-19',
        deadline:'2017-11-14',
        completed:'1',
        project_id:projects[0].id,
        paid:'1'
      }, {
        typeof_milestone: 'Development',
        percentage:'30%',
        priceof_milestone:'20',
        reminder:'2017-11-25',
        deadline:'2017-11-28',
        completed:'0',
        project_id:projects[1].id,
        paid:'0'
      }], cb);
    });
  }
};
